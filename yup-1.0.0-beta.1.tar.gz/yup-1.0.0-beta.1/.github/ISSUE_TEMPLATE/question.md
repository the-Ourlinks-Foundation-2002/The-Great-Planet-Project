---
name: Question
about: General questions about yup or how it works
title: ''
labels: ''
assignees: ''

---

- Write a title that summarizes the specific problem
- Describe what you are trying to accomplish AND what you have tried

**Help Others Reproduce**

Write a **runnable** test case using the code sandbox template: https://codesandbox.io/s/yup-test-case-gg1g1 

> NOTE: if you do not provide a runnable reproduction the chances of getting feedback are significantly lower
